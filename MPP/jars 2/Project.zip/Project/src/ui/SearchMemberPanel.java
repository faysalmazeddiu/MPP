package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import business.Address;
import business.Author;
import business.Book;
import business.ControllerInterface;
import business.LibraryMember;
import business.SystemController;
import dataaccess.DataAccessFacade;
import librarysystem.LibrarySystem;
import ui.AddBookPanel.AuthorListener;
import ui.AddBookPanel.ClearListener;
import ui.AddBookPanel.SaveListener;
import utils.DefaultData;
import utils.GuiControl;
import utils.Util;

public class SearchMemberPanel extends JFrame{
	
	DataAccessFacade daf = new DataAccessFacade();
	
	public JPanel getMainPanel() {
		return mainPanel;
	}
	
	private JTextField searchField;
	private JButton searchButton;
	

	//JPanels		
	JPanel mainPanel;
	JPanel upper, middle;
	
	public SearchMemberPanel() {
		initializeWindow();
		defineMainPanel();
		getContentPane().add(mainPanel);
			
	}
	
	
	private void initializeWindow() {
		
		setSize(Math.round(.7f*GuiControl.SCREEN_WIDTH),
				Math.round(.7f*GuiControl.SCREEN_HEIGHT));
		GuiControl.centerFrameOnDesktop(this);
		
	}
	
	private void defineMainPanel() {
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		defineUpperPanel();
		defineMiddlePanel();
		mainPanel.add(upper,BorderLayout.NORTH);
		mainPanel.add(middle,BorderLayout.CENTER);
			
	}
	//label
	public void defineUpperPanel(){
		upper = new JPanel();
		upper.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		JLabel mainLabel = new JLabel(DefaultData.SEARCH_BY_MEMBER_ID);
		Font f = GuiControl.makeVeryLargeFont(mainLabel.getFont());
		f = GuiControl.makeBoldFont(f);
		mainLabel.setFont(f);
		upper.add(mainLabel);					
	}

	//table
	public void defineMiddlePanel(){
		middle = new JPanel();
		middle.setLayout(new FlowLayout(FlowLayout.CENTER));
		JPanel gridPanel = new JPanel();
		middle.add(gridPanel);
		GridLayout gl = new GridLayout(1,2);
		gl.setHgap(8);
		gl.setVgap(8);
		gridPanel.setLayout(gl);
		
		searchField = new JTextField(12);
		makeLabel(gridPanel,searchField);
		searchButton = new JButton(DefaultData.SEARCH_BUTN);
		searchButton.setMaximumSize(new Dimension(20, 40));
		searchButton.addActionListener(new SearchListener());
		gridPanel.add(searchButton);
		
	}
	
	private void makeLabel(JPanel p, JTextField field) {
		p.add(leftPaddedPanel(field));
	}
	private JPanel leftPaddedPanel(JTextField label) {
		JPanel paddedPanel = new JPanel();
		paddedPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		paddedPanel.add(GuiControl.createHBrick(1));
		paddedPanel.add(label);
		return paddedPanel;		
	}
	
						
	class SearchListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
        	String s = searchField.getText().toString();
        	LibraryMember member = daf.readMemberById(s);
        	if (member != null) {
				showInfo(String.format("ID: %s, Name: %s %s, Phone: %s", 
						member.getMemberId(), member.getFirstName(), 
						member.getLastName(), member.getTelephone()));
			}else {
				showError("Sorry, Member not found!");
			}
        	
        }
	}
	
	private static final long serialVersionUID = 1L;

	
	private void showInfo(String msg) {
		LibrarySystem.INSTANCE.statusBar.setForeground(Util.INFO_MESSAGE_COLOR);
		LibrarySystem.INSTANCE.statusBar.setText(msg);
	}
	
	private void showError(String msg) {
		LibrarySystem.INSTANCE.statusBar.setForeground(Util.ERROR_MESSAGE_COLOR);
		LibrarySystem.INSTANCE.statusBar.setText(msg);
	}
	
}
