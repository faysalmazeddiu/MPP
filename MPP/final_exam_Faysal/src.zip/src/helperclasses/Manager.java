package helperclasses;

public class Manager extends Employee {
	public Manager(int id, String n, int s) {
		super(id, n,s);
	}
}
