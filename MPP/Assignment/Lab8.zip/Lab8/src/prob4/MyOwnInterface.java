package prob4;

import java.util.List;

public interface MyOwnInterface {
	public int countWords(List<String> words, char c, char d, int len);
}
