package prog1.partE;

public interface A {
	abstract public void method();
}
