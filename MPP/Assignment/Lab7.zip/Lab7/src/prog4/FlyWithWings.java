package prog4;

public class FlyWithWings implements FlyBehavior{

	@Override
	public void fly() {
		System.out.println("fly with Wings");
	}

}
