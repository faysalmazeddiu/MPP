package prog4;

public class RedheadDuck extends Duck {

	public RedheadDuck() {
		
	}
	
	@Override
	public void display() {
		System.out.println("Displaying - RedheadDuck");
	}

}
