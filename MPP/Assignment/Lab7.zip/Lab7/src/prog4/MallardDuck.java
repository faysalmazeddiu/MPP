package prog4;

public class MallardDuck extends Duck{

	public MallardDuck() {
		
	}

	@Override
	public void display() {
		System.out.println("Displaying - MallardDuck");
	}

}
