package prob4;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
