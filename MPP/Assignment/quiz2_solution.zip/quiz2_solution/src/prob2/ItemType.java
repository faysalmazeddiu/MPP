package prob2;

public enum ItemType {
	BOOK, CD;
}
