package prob2;

public interface Shape {
	public double computeArea();
}
