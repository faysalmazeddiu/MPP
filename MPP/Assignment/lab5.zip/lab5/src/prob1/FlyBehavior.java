package prob1;

public interface FlyBehavior {
	abstract void fly();
}
