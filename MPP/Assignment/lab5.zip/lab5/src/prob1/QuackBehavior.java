package prob1;

public interface QuackBehavior {
	abstract void quack();
}
