package prob4.properties;

public abstract class Property {
	abstract public double computeRent();
}
