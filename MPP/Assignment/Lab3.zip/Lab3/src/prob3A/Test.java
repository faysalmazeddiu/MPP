package prob3A;

public class Test {

	public static void main(String[] args) {
		Circle circle = new Circle(15);
		System.out.println(circle.computeArea());
		System.out.println(circle.computeVolume());
	}
}
