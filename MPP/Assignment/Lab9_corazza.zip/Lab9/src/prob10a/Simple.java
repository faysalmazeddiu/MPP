package prob10a;

public class Simple {
	boolean flag = false;
	public Simple(boolean f) {
		flag = f;
	}
}
