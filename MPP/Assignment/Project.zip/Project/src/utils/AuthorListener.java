package utils;

import business.Author;

public interface AuthorListener {
	public void addAuthor(Author author);
}
