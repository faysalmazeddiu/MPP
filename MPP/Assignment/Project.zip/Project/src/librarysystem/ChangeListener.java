package librarysystem;

public interface ChangeListener {
	public void onChanged();
}
