package prob2B;

public class Main {
	public static void main(String[] args) {
		Order order = new Order(234, "Mobile");
		order.getOrderDetails();
	}
}
