package prob2;

public interface QuackBehavior {
	abstract void quack();
}
