package prob2;

public interface FlyBehavior {
	abstract void fly();
}
