package prob;

import java.io.Serializable;

public enum Auth implements Serializable {
	MEMBER, SELLER, BOTH;
}
