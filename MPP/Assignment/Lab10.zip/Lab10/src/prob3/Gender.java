package prob3;

public enum Gender {
	M, F
}
