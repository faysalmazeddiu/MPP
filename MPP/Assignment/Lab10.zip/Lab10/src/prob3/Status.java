package prob3;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
